#ifndef HD_H_INCLUDED
#define HD_H_INCLUDED

typedef struct cases{

int bombe;     /// O si pas de bombe 1 si bombe
int cote;     /// nombre de cote qui touche bombe
char marquage; /// 0 si pas de marqueur 1 si marque
int etatb;    /// 0 si encore active 1 si decouverte
int etatcote; /// 0 si pas decouvert 1 si decouvert


}t_cases;
void InitialtabFacile(t_cases tab[10][10]);
void remplissagecasesFacile(t_cases tab[10][10]);
void affichageFacile(t_cases tab[10][10]);
void JeuxFacile(t_cases tab[10][10]);
void recursiviteFacile(t_cases tab[10][10], int i,int j);
void InitialtabIntermediaire(t_cases tab[17][17]);
void remplissagecasesIntermediaire(t_cases tab[17][17]);
void affichageIntermediaire(t_cases tab[17][17]);
void JeuxIntermediaire(t_cases tab[17][17]);
void recursiviteIntermediaire(t_cases tab[17][17], int i,int j);
void ecranVictoire();
void ecranDefaite();
void ecranCredits();
void reglesDemineur();
void ecranMenu(t_cases Tab1[10][10],t_cases Tab2[17][17]);

#include<stdio.h>
#include<stdlib.h>
#include<time.h>

#endif // HD_H_INCLUDED
