#include "HD.h"


int main()
{
    srand(time(NULL));
    t_cases Tab1[10][10];
    t_cases Tab2[16][16];
    ecranMenu(Tab1,Tab2);


    return 0;
}
