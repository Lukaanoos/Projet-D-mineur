////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#include "HD.h"
void InitialtabFacile(t_cases tab[10][10])
{
    int i,j;
    for (i=0; i<10; i++)
    {
        for (j=0; j<10; j++)
        {
            tab[i][j].bombe=0;
            tab[i][j].cote=0;
            tab[i][j].etatcote=0;
            tab[i][j].etatb=0;
            tab[i][j].marquage='0';

        }
    }
}






void remplissagecasesFacile(t_cases tab[10][10])
{
    int alea,alea2;
    int compteur=0;
    int compteurfinal=0;

    do
    {

        alea=rand()%9;
        alea2=rand()%9;
        if (tab[alea][alea2].bombe==1)
        {
            compteur=1;
        }
        else
        {
            tab[alea][alea2].bombe=1;
            tab[alea][alea2].etatcote=1;
            tab[alea][alea2].cote=7;
            tab[alea+1][alea2].cote++;
            tab[alea+1][alea2-1].cote++;
            tab[alea+1][alea2+1].cote++;
            tab[alea-1][alea2].cote++;
            tab[alea-1][alea2+1].cote++;
            tab[alea-1][alea2-1].cote++;
            tab[alea][alea2+1].cote++;
            tab[alea][alea2-1].cote++;
            compteur=0;
            compteurfinal++;
        }


    }
    while((compteur==1)||(compteurfinal<10));

}



void affichageFacile(t_cases tab[10][10])
{
    printf("Voici votre Grille:\n");
    printf("  1 2 3 4 5 6 7 8 9 \n");
    int i=0,j=0;
    for (i=0; i<9; i++)
    {
        for (j=0; j<9; j++)
        {
            if(j==0)
            {
                printf("%d",i+1);
            }
            if (tab[i][j].marquage=='0')
            {

                if (tab[i][j].etatcote==0)
                {
                    printf("| ");
                }
                if (tab[i][j].etatcote==1)
                {
                    if (tab[i][j].cote>=7)
                    {
                        printf("| ");
                    }
                    else
                    {
                        printf("|%d",tab[i][j].cote);
                    }
                }
            }
            else
            {
                if (tab[i][j].marquage=='x')
                {
                    printf("|%c",tab[i][j].marquage);
                }
            }


            if(j==8)
            {
                printf("|");
                printf("\n");
            }
        }
    }
}
void JeuxFacile(t_cases tab[10][10])
{

    int choix;
    int nbligne,nbcolone;
    int compteur=10;
    int i,j;
    int perdu=0,gagne=0;
    time_t debut, fin ;
    double difference ;


debut=time(NULL) ;
    do
    {
        gagne=0;
        affichageFacile(tab);
        printf("\n");
        printf("Il reste %d bombes a placer.\n",compteur);
        do
        {
            printf("Voulez vous :\n");
            printf(" 1. Decouvrir une case\n");
            printf(" 2. Placer un marqueur de bombe\n");
            scanf("%d",&choix);
        }
        while ((choix!=1)&&(choix!=2));

        if (choix==1)
        {
            do
            {
                printf("Veuillez indiquer les coordonnees \n") ;
                printf("Quelle ligne:\n");
                scanf("%d",&nbligne);
                printf("Quelle colonne:\n");
                scanf("%d",&nbcolone);
            }
            while((nbligne<1)||(nbligne>9)||(nbcolone<1)||(nbcolone>9));
            if (tab[nbligne-1][nbcolone-1].bombe==1)
            {
                perdu=1;
            }
            else
            {
                if (tab[nbligne-1][nbcolone-1].cote>0)
                {
                    tab[nbligne-1][nbcolone-1].etatcote=1;
                }
                else
                {
                    recursiviteFacile(tab,nbligne-1,nbcolone-1);
                }
            }

        }
        else
        {
            if (compteur>0)
            {
                do
                {
                    printf("Veuillez indiquer les coordonnees \n") ;
                    printf("Quelle ligne:\n");
                    scanf("%d",&nbligne);
                    printf("Quelle colonne:\n");
                    scanf("%d",&nbcolone);
                }
                while((nbligne<1)||(nbligne>9)||(nbcolone<1)||(nbcolone>9));
                tab[nbligne-1][nbcolone-1].marquage='x';
                compteur--;
            }
            else
            {
                printf("Vous n'avez plus de marqueur.\n");
                printf("\n");
            }
        }

        for (i=0; i<9; i++)
        {
            for (j=0; j<9; j++)
            {

                if (tab[i][j].etatcote==1)
                {
                    gagne++;
                }

            }

        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    while ((perdu==0)&&(gagne<81));
    if (perdu==1)
    {
        printf("                          BOOOOMM !!\n\n\n");
        printf("Une mine a explose !!\n");
        printf("Vous venez de tuer un bon nombre d'innocents et vous compris..\n");
        printf("Je vous avais pourtant dit de ne jamais toucher au fil rouge...\n");
        printf("Heureusement pour vous ce n'est qu'un jeu. \n");
        printf("N'hesitez pas a retentez votre chance !\n");

    }
    if (gagne==81)
    {
        printf("                           VICTOIRE !!\n\n\n");
        printf("Bravo a vous, vous avez demine toute la grille !\n");
        fin=time(NULL) ;
        difference = difftime(fin, debut) ;
        printf("Votre temps est de ':%lf ' secondes\n\n",difference);
    }
}

void recursiviteFacile(t_cases tab[10][10], int i,int j)
{
    if (tab[i][j].etatcote==0)
    {
        tab[i][j].etatcote=1;
        if (tab[i][j].cote==0)
        {
            if (i>0)
            {
                recursiviteFacile(tab,i-1,j);
            }
            if ((i>0 )&&(j>0))
            {
                recursiviteFacile(tab,i-1,j-1);
            }
            if (j>0)
            {
                recursiviteFacile(tab,i,j-1);
            }
            if ((j>0 )&&(i<8))
            {
                recursiviteFacile(tab,i+1,j-1);
            }
            if (i<8)
            {
                recursiviteFacile(tab,i+1,j);
            }
            if ((i>8 )&&(j<8))
            {
                recursiviteFacile(tab,i+1,j+1);
            }
            if (j<8)
            {
                recursiviteFacile(tab,i,j+1);
            }
            if ((i>0 )&&(j<8))
            {
                recursiviteFacile(tab,i-1,j+1);
            }
        }
    }

}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void InitialtabIntermediaire(t_cases tab[17][17])
{
    int i,j;
    for (i=0; i<17; i++)
    {
        for (j=0; j<17; j++)
        {
            tab[i][j].bombe=0;
            tab[i][j].cote=0;
            tab[i][j].etatcote=0;
            tab[i][j].etatb=0;
            tab[i][j].marquage='0';

        }
    }
}






void remplissagecasesIntermediaire(t_cases tab[17][17])
{
    int alea,alea2;
    int compteur=0;
    int compteurfinal=0;

    do
    {

        alea=rand()%16;
        alea2=rand()%16;
        if (tab[alea][alea2].bombe==1)
        {
            compteur=1;
        }
        else
        {
            tab[alea][alea2].bombe=1;
            tab[alea][alea2].etatcote=1;
            tab[alea][alea2].cote=7;
            tab[alea+1][alea2].cote++;
            tab[alea+1][alea2-1].cote++;
            tab[alea+1][alea2+1].cote++;
            tab[alea-1][alea2].cote++;
            tab[alea-1][alea2+1].cote++;
            tab[alea-1][alea2-1].cote++;
            tab[alea][alea2+1].cote++;
            tab[alea][alea2-1].cote++;
            compteur=0;
            compteurfinal++;
        }


    }
    while((compteur==1)||(compteurfinal<40));

}



void affichageIntermediaire(t_cases tab[17][17])
{
    printf("Voici votre Grille:\n");
    printf("   1 2 3 4 5 6 7 8 9 10111213141516 \n");
    int i=0,j=0;
    for (i=0; i<16; i++)
    {
        for (j=0; j<16; j++)
        {
            if(j==0)
            {
                if (i<9)
                {
                    printf(" %d",i+1);
                }
                else
                {
                    printf("%d",i+1);
                }

            }

            if (tab[i][j].marquage=='0')
            {

                if (tab[i][j].etatcote==0)
                {
                    printf("| ");
                }
                if (tab[i][j].etatcote==1)
                {
                    if (tab[i][j].cote>=7)
                    {
                        printf("| ");
                    }
                    else
                    {
                        printf("|%d",tab[i][j].cote);
                    }
                }
            }
            else
            {
                if (tab[i][j].marquage=='x')
                {
                    printf("|%c",tab[i][j].marquage);
                }
            }


            if(j==15)
            {
                printf("|");
                printf("\n");
            }
        }
    }
}
void JeuxIntermediaire(t_cases tab[17][17])
{

    int choix;
    int nbligne,nbcolone;
    int compteur=40;
    int i,j;
    int perdu=0,gagne=0;
    time_t debut, fin ;
    double difference ;
    do
    {
        gagne=0;
        affichageIntermediaire(tab);
        printf("\n");
        printf("Il reste %d bombes a placer.\n",compteur);
        do
        {
            printf("Voulez vous :\n");
            printf(" 1. Decouvrir une case\n");
            printf(" 2. Placer un marqueur de bombe\n");
            scanf("%d",&choix);
        }
        while ((choix!=1)&&(choix!=2));

        if (choix==1)
        {
            do
            {
                printf("Veuillez indiquer les coordonnees \n") ;
                printf("Quelle ligne:\n");
                scanf("%d",&nbligne);
                printf("Quelle colonne:\n");
                scanf("%d",&nbcolone);
            }
            while((nbligne<1)||(nbligne>16)||(nbcolone<1)||(nbcolone>16));
            if (tab[nbligne-1][nbcolone-1].bombe==1)
            {
                perdu=1;
            }
            else
            {
                if (tab[nbligne-1][nbcolone-1].cote>0)
                {
                    tab[nbligne-1][nbcolone-1].etatcote=1;
                }
                else
                {
                    recursiviteIntermediaire(tab,nbligne-1,nbcolone-1);
                }
            }

        }
        else
        {
            if (compteur>0)
            {
                do
                {
                    printf("Veuillez indiquer les coordonnees \n") ;
                    printf("Quelle ligne:\n");
                    scanf("%d",&nbligne);
                    printf("Quelle colonne:\n");
                    scanf("%d",&nbcolone);
                }
                while((nbligne<1)||(nbligne>16)||(nbcolone<1)||(nbcolone>16));
                tab[nbligne-1][nbcolone-1].marquage='x';
                compteur--;
            }
            else
            {
                printf("Vous n'avez plus de marqueur.\n");
                printf("\n");
            }
        }

        for (i=0; i<16; i++)
        {
            for (j=0; j<16; j++)
            {

                if (tab[i][j].etatcote==1)
                {
                    gagne++;
                }

            }

        }
    }
    while ((perdu==0)&&(gagne<256));
    if (perdu==1)
    {
        printf("                          BOOOOMM !!\n\n\n");
        printf("Une mine a explose !!\n");
        printf("Vous venez de tuer un bon nombre d'innocents et vous compris..\n");
        printf("Je vous avais pourtant dit de ne jamais toucher au fil rouge...\n");
        printf("Heureusement pour vous ce n'est qu'un jeu. \n");
        printf("N'hesitez pas a retentez votre chance !\n");

    }
    if (gagne==256)
    {
        printf("                           VICTOIRE !!\n\n\n");
        printf("Bravo a vous, vous avez demine toute la grille !\n");
        fin=time(NULL) ;
        difference = difftime(fin, debut) ;

        printf("Votre temps est de ':%lf ' secondes\n\n",difference);
    }
}

void recursiviteIntermediaire(t_cases tab[17][17], int i,int j)
{
    if (tab[i][j].etatcote==0)
    {
        tab[i][j].etatcote=1;
        if (tab[i][j].cote==0)
        {
            if (i>0)
            {
                recursiviteIntermediaire(tab,i-1,j);
            }
            if ((i>0 )&&(j>0))
            {
                recursiviteIntermediaire(tab,i-1,j-1);
            }
            if (j>0)
            {
                recursiviteIntermediaire(tab,i,j-1);
            }
            if ((j>0 )&&(i<15))
            {
                recursiviteIntermediaire(tab,i+1,j-1);
            }
            if (i<15)
            {
                recursiviteIntermediaire(tab,i+1,j);
            }
            if ((i>15 )&&(j<15))
            {
                recursiviteIntermediaire(tab,i+1,j+1);
            }
            if (j<15)
            {
                recursiviteIntermediaire(tab,i,j+1);
            }
            if ((i>0 )&&(j<15))
            {
                recursiviteIntermediaire(tab,i-1,j+1);
            }
        }
    }

}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void ecranVictoire()
{
    printf("                           VICTOIRE !!\n\n\n");
    printf("Bravo � vous, vous avez d�min� toute la grille !\n");
    printf("Votre temps est de :\n\n");
    //appel de la fonction timer necessaire

}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void ecranDefaite()
{
    printf("                          BOOOOMM !!\n\n\n");
    printf("Une mine a explos� !!\n");
    printf("Vous venez de tuer un bon nombre d'innocents et vous compris..\n");
    printf("Je vous avais pourtant dit de ne jamais toucher au fil rouge...\n");
    printf("Heureusement pour vous ce n'est qu'un jeu. \nN'h�sitez pas � retentez votre chance !");


}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void ecranCredits()
{
    printf("Merci a vous d'avoir joue a notre Demineur.\nOn espere que celui-ci vous aura plu et on vous souhaite de battre tous les records !!\nEnfin si vous vous en sentez capables bien sur ....\n");
    printf("-----------------------                                                      -----------------------\n");
    printf("-----------------------\nS/o :\n    :@Wiskoo\n    :@Lukaanoos\n    :@nc_326\n-----------------------\n");
    printf("-----------------------                                                      -----------------------\n");
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void reglesDemineur()
{
    printf("                                      Comment jouer au demineur ?   \n\n");
    printf("\nVous devez d�miner un champ de mines. Pour cela, il a �t� d�coup� en carr�s qui peuvent contenir\nsoit une seule mine 'X', soit aucune.\nAu d�but, les mines, enterr�es, ne sont bien �videment pas visibles.\n");
    printf("\nPour gagner au D�mineur, il vous faut d�terminer l'emplacement de toutes les mines.\n");
    printf("\nPour atteindre cet objectif, vous pourrez prendre connaissance du nombre de mines \ndans le voisinage imm�diat d'une case, en choisissant l'option 'D�couvrir une case' puis en indiquant \nses coordonn�es et � condition qu'elle ne cache pas une mine. \nCar attention, si jamais vous d�voilez une case contenant une mine, vous perdrez automatiquement la partie !\n");
    printf("\nIl vous est aussi possible de 'Placer un marqueur de mines', permettant d'indiquer l'emplacement suppos� d'une mine.\n");
    printf("Si la case d�couverte est vide et ne se trouve pas � c�t� d'une bombe, toutes les autres cases vides adjacentes \ns'ouvriront � la suite jusqu'� tomber sur une case coll�e � une bombe.\n");
    printf("\nPour gagner, il ne doit pas y avoir de mines incorrectement marqu�e.\nEn revanche, il n'est pas n�cessaire de marquer toutes les mines pour terminer la partie; \nvous avez juste besoin de d�couvrir toutes les cases vides.");
    printf("\nChaque partie est chronom�tr�e, le timer s'affichera apr�s chaque victoire et sera enregistr�e dans un fichier \nafin de conserver vos meilleurs performances.");
    printf("\n\nAlors vous aussi, lancez vous dans l'aventure du D�mineur mais surtout n'oubliez pas:");
    printf("\n\n                                    Ne touchez JAMAIS au fil rouge ...!!");
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void ecranMenu(t_cases Tab1[10][10],t_cases Tab2[17][17])
{
    int c;
    printf("---------      ----      -----------\n");
    printf("         ------    ------           \n");
    printf("-------------        ---------------\n");
    printf("-----------            -------------\n");
    printf("---------    DEMINEUR    -----------\n");
    printf("-----------            -------------\n");
    printf("-------------        ---------------\n");
    printf("         ------    ------           \n");
    printf("--------       ----      -----------\n");
    printf("\n\n\n\n");
    do
    {
        printf("Que souhaitez-vous faire ?\n\n");
        printf("1.Mode Facile.             \t2.Mode Intermediaire.\n3.Comment Jouer ?              \t4.Credits.\n");
        scanf("%d",&c);
    }
    while(c<1 || c>4);
    if(c==1)
    {
        InitialtabFacile(Tab1);
        remplissagecasesFacile(Tab1);
        JeuxFacile(Tab1);
    }
    else
    {
        if(c==2)
        {
            InitialtabIntermediaire(Tab2);
            remplissagecasesIntermediaire(Tab2);
            JeuxIntermediaire(Tab2);
        }
        else
        {
            if(c==3)
            {
                reglesDemineur();
            }
            else
            {
                ecranCredits();
            }
        }
    }

}


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
